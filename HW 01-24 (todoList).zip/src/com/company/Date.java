package com.company;

public class Date {

    public String date;

    public Date() {}
}
