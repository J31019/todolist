package com.company;

public enum Status {
    Done,
    NotDone;

    private Status() {}

}
