package com.company;

import java.io.PrintStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Scanner;
import java.util.Map.Entry;

public class Options {

    static HashMap<Object, HashMap<String, Status>> todoList1 = new HashMap();
    private Date data1 = new Date();
    private Val val = new Val();
    HashMap<String, Status> a = new HashMap();

    public Options() {}

    public void addTime() throws Exception {
        this.val.status = Status.NotDone;
        Scanner sc = new Scanner(System.in);
        boolean b = true;

        while (b) {
            try {
                System.out.println("Введите дату в формате DD/MM/YYYY ");
                this.data1.date = sc.nextLine();
                SimpleDateFormat simpleDF = new SimpleDateFormat("DD/MM/YY");
                java.util.Date d = simpleDF.parse(this.data1.date);
                simpleDF.format(d);
                b = false;
            } catch (Exception e) {
                System.out.println("Неправильно введена дата. ");
            }
        }

        System.out.println("Введите задание ");
        this.val.description = sc.nextLine();
        if (todoList1.containsKey(this.data1.date)) {
            HashMap<String, Status> a = todoList1.get(this.data1.date);
            if (a.containsKey(this.val.description)) {
                System.out.println("Такое задание уже есть в списке на эту дату");
            } else {
                a.put(this.val.description, this.val.status);
                todoList1.put(this.data1, a);
            }
        } else {
            this.a.put(this.val.description, this.val.status);
            todoList1.put(this.data1.date, this.a);
        }
    }

    public void showTodoList() throws Exception {
        System.out.println("1. На сегодня");
        System.out.println("2. На эту неделю");
        System.out.println("3. На выбранную дату");
        System.out.println("4. Весь список");
        System.out.println("5. Назад");
        Scanner sc = new Scanner(System.in);
        int i = sc.nextInt();
        switch (i) {
            case 1:
                System.out.println("Список дел на сегодня: ");
                java.util.Date DateToday = new java.util.Date();
                SimpleDateFormat simpleDF = new SimpleDateFormat("DD/MM/YYYY");
                System.out.println(simpleDF.format(DateToday));
                if (todoList1.containsKey(simpleDF.format(DateToday))) {
                    System.out.println(todoList1.get(simpleDF.format(DateToday)));
                } else {
                    System.out.println("На сегодня ничего не запланировано");
                }
                break;

            case 2:
                System.out.println("Список дел на текущую неделю: ");
                Calendar c = GregorianCalendar.getInstance();
                c.set(7, 2);
                DateFormat df = new SimpleDateFormat("DD/MM/YYYY", Locale.getDefault());
                c.add(5, 0);
                String day = df.format(c.getTime());
                if (todoList1.containsKey(day)) {
                    System.out.println(day + " " + todoList1.get(day));
                }
                for (int in = 0; in < 6; ++i) {
                    c.add(5, 1);
                    day = df.format(c.getTime());
                    if (todoList1.containsKey(day)) {
                        System.out.println(day + " " + todoList1.get(day));
                    }
                }
                System.out.println("Дел на текущую неделю не запланировано ");
                break;

            case 3:
                try {
                    System.out.println("Введите необходимую дату в формате DD/MM/YYYY");
                    Date dd = new Date();
                    dd.date = sc.nextLine();
                    SimpleDateFormat sDF = new SimpleDateFormat("DD/MM/YY");
                    java.util.Date d = sDF.parse(dd.date);
                    sDF.format(d);
                    if (todoList1.containsKey(dd.date)) {
                        String v = dd.date;
                        System.out.println(" Список дел на " + v + todoList1.get(dd));
                    } else {
                        System.out.println("Дел на " + dd.date + "не запланировано");
                    }
                } catch (Exception e) {
                    System.out.println("Некорректно введена дата");
                }
                break;

            case  4:
                if (todoList1.isEmpty()) {
                    System.out.println("Список дел пуст");
                } else {
                    System.out.println("Весь список дел: ");
                    Iterator it = todoList1.entrySet().iterator();

                    while (it.hasNext()) {
                        Entry en = (Entry)it.next();
                        System.out.println(en);
                    }
                }
            case 5:

            default:
                System.out.println("Некорректно ввели номер пункта");
        }
    }

    public void val2() throws Exception {
        try {
            System.out.println(" Введите дату в формате ");
            Scanner sc= new Scanner(System.in);
            Date dd = new Date();
            dd.date = sc.nextLine();
            SimpleDateFormat sdf = new SimpleDateFormat("DD/MM/YY");
            java.util.Date d = sdf.parse(dd.date);
            sdf.format(d);
            if (todoList1.containsKey(dd.date)) {
                new HashMap();
                HashMap<String, Status> mList = todoList1.get(dd.date);
                ArrayList<String> listVal = new ArrayList(mList.keySet());
                ArrayList<Status> listStatus = new ArrayList(mList.values());

                int n;
                for (n = 0; n < listVal.size(); ++n) {
                    System.out.println(n + 1 + "  " + (String) listVal.get(n) + " " + listStatus.get(n));
                }

                System.out.println(" Введите номер дела, который хотите отредактировать ");
                n = sc.nextInt();
                PrintStream ps = System.out;
                String s = (String) listVal.get(n - 1);
                ps.println(s + " " + listStatus.get(n - 1));
                System.out.println("1. Изменить описание.");
                System.out.println("2. Удалить");
                System.out.println("3. Пометить как выполненное.");
                System.out.println("4. Пометьть как невыполненное.");
                System.out.println("5. Отмена.");

                int nMenu = sc.nextInt();
                HashMap a;
                Object ob;

                switch (nMenu) {
                    case 1:
                        System.out.println("Введите новое задание ");
                        String str = sc.nextLine();
                        a = todoList1.get(dd.date);
                        Status stat = (Status) a.get(listVal.get(n - 1));
                        a.remove(listVal.get(n - 1));
                        this.val.status = stat;
                        a.put(str, this.val.status);
                        todoList1.put(dd.date, a);
                        break;

                    case 2:
                        System.out.println("Вы действительно хотите удалить выбранное дело? (да/нет)");
                        String answer = sc.nextLine();
                        if (answer.equals("да")) {
                            a = todoList1.get(dd.date);
                            a.remove(listVal.get(n - 1));
                            if (a.isEmpty()) {
                                todoList1.remove(dd.date);
                            }

                            System.out.println("Удалено из списка");
                        } else if (answer.equals("нет")) {
                            System.out.println("Выбранное дело не удалено из списка.");
                        } else {
                            System.out.println("Введите либо 'да', либо 'нет' ");
                        }
                        break;

                    case 3:
                        a = todoList1.get(dd.date);
                        Status st = (Status) a.get(listVal.get(n - 1));
                        if (st == Status.Done) {
                            System.out.println("Задание уже выполнено");
                        } else {
                            a.put((String) listVal.get(n - 1), Status.Done);
                            ps = System.out;
                            ob = listVal.get(n - 1);
                            ps.println("Дело " + ob + " помечено как 'Невыполненое' ");
                        }
                        break;

                    case 4:
                        a = todoList1.get(dd.date);
                        Status stt = (Status) a.get(listVal.get(n - 1));
                        if (stt == Status.Done) {
                            a.put(listVal.get(n - 1), Status.NotDone);
                            ps = System.out;
                            ob = listVal.get(n - 1);
                            ps.println(" Дело " + ob + " помечено как 'невыполнено' ");
                        }
                        break;
                    case 5:
                        break;
                    default:
                        System.out.println(" проверьте номер который ввели");
                }
            } else {
                System.out.println("На эту дату дел нет");
            }
        } catch (Exception e ) {
            System.out.println("Неправильно введена дата");
        }
    }



}
