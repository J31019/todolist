package com.company;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws Exception {

        new Date();
        new SimpleDateFormat("DD/MM/YYYY");
        boolean exitValue = true;

        try {
            FileInputStream fileIS = new FileInputStream("todoList.bin");
            ObjectInputStream objectIS = new ObjectInputStream(fileIS);
            HashMap<Object, HashMap<String, Status>> todoList = (HashMap)objectIS.readObject();
            objectIS.close();
            fileIS.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        Scanner sc = new Scanner(System.in);

        while (exitValue) {
            System.out.println("Выберите нужный пункт из перечисленных");
            System.out.println("1. Добавить задание");
            System.out.println("2. Выбрать задание");
            System.out.println("3. Показать список дел ");
            System.out.println("4. Завершить работу");

            int scValue = sc.nextInt();
            switch (scValue) {
                case 1:
                    Options opt = new Options();
                    opt.addTime();
                    break;
                case 2:
                    Options opt2 = new Options();
                    opt2.val2();
                    break;
                case 3:
                    Options opt3 = new Options();
                    opt3.showTodoList();
                    break;
                case 4:
                    try {
                        FileOutputStream fak = new FileOutputStream("todoList.bin");
                        ObjectOutputStream o = new ObjectOutputStream(fak);
                        o.writeObject(Options.todoList1);
                        o.close();
                        fak.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    System.out.println("Завершение работы.");
                    exitValue = true;
            }
        }

    }
}
