package com.company;

public class Val {
    public String description;
    public Status status;

    public Val() {}

}
